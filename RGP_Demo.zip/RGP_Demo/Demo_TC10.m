clc;
clear all;
close all;

load('mapping2.mat');
rootpic = '/Desktop/research/dataset/texture dataset/Outex_TC_00010/';

LBPhist = [];
Total_Num   = 4320;

trainTxt = sprintf('%s000//train.txt', rootpic);  % ѵ����
testTxt = sprintf('%s000//test.txt', rootpic);  % ���Լ�


[trainIDs, trainClassIDs] = ReadOutexTxt(trainTxt); % ѵ����
[testIDs, testClassIDs] = ReadOutexTxt(testTxt);% ���Լ�


uper = 1;
lower = 0;
a = lower+(uper-lower).*rand([1 1]);
b = 255;
r1 = 1;
r2 = 2;
r3 = 3;


for n=1:length(a)
    tic
    for i =1:Total_Num
        filename = sprintf('%s//images//%06d.ras', rootpic, i-1);
        display([num2str(n) '.... '  filename ])
        img = im2double(imread(filename));
        img = (img-mean(img(:)))/std(img(:))*20+128;
        if any(testIDs == i)
            Gray = -a(n).*((img)) + b;
%             Gray = -sqrt(img) + b;
        else
            Gray = img;
        end
        
       hists1(i,:) = [space_gv_diff(Gray,r1,8,mapping2_1,'x')  space_gvm_diff(Gray,r1,8,mapping2_1,'x')];
       hists2(i,:) = [space_gv_diff(Gray,r2,16,mapping2_2,'x') space_gvm_diff(Gray,r2,16,mapping2_2,'x')];
       hists3(i,:) = [space_gv_diff(Gray,r3,24,mapping2_3,'x') space_gvm_diff(Gray,r3,24,mapping2_3,'x')];  
        
    end
    disp(['ƽ��ÿ����������ʱ��Ϊ ' num2str(toc/Total_Num) ' ��'])
    
    hists4 = [hists1,hists2,hists3];    
    
    CP1 = cal_AP(hists1,trainIDs,trainClassIDs,testIDs,testClassIDs); 
    CP2 = cal_AP(hists2,trainIDs,trainClassIDs,testIDs,testClassIDs); 
    CP3 = cal_AP(hists3,trainIDs,trainClassIDs,testIDs,testClassIDs); 
    CP4 = cal_AP(hists4,trainIDs,trainClassIDs,testIDs,testClassIDs); 

    
end

