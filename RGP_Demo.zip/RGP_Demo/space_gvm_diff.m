
function LVPjoint1 = space_gvm_diff(image,R,P,mapping,mode) % image,R,P,mapping,mode)

    a = 2*pi/P;
    
    for i = 1:P
        spoints(i,1) = -R*sin((i-1)*a);
        spoints(i,2) = R*cos((i-1)*a);
    end
    

% Determine the dimensions of the input image.
[ysize xsize] = size(image);


d_image=double(image);

miny=min(spoints(:,1));
maxy=max(spoints(:,1));
minx=min(spoints(:,2));
maxx=max(spoints(:,2));

% Block size, each LBP code is computed within a block of size bsizey*bsizex
bsizey=ceil(max(maxy,0))-floor(min(miny,0))+1;
bsizex=ceil(max(maxx,0))-floor(min(minx,0))+1;

% Coordinates of origin (0,0) in the block
origy=1-floor(min(miny,0));
origx=1-floor(min(minx,0));

% Minimum allowed size for the input image depends
% on the R of the used LBP operator.
if(xsize < bsizex || ysize < bsizey)
  error('Too small input image. Should be at least (2*R+1) x (2*R+1)');
end

% Calculate dx and dy;
dx = xsize - bsizex;
dy = ysize - bsizey;

% Fill the center pixel matrix C.
C = image(origy:origy+dy,origx:origx+dx);
d_C = double(C);
thre_imagec = thre_xyq(d_image,3,3);
thre_C =thre_imagec(origy:origy+dy,origx:origx+dx);

var_image = thre_var2(d_image,3,3);
var_1 =var_image(origy:origy+dy,origx:origx+dx,1);
var_2 =var_image(origy:origy+dy,origx:origx+dx,2);
var_3 =var_image(origy:origy+dy,origx:origx+dx,3);


max_image = thre_max(d_image,3,3);
th_max =max_image(origy:origy+dy,origx:origx+dx);

min_image = thre_min(d_image,3,3);
th_min =min_image(origy:origy+dy,origx:origx+dx);

th_abs=abs(th_max-th_min);


% bins = 2^P;
% aver=mean2(d_image);
% Initialize the result matrix with zeros.

g_diff=zeros(dy+1,dx+1);
sum_N=zeros(dy+1,dx+1);
VAR=zeros(dy+1,dx+1);
VARC=zeros(dy+1,dx+1);
%Compute the LBP code image
for i = 1:P
  y = spoints(i,1)+origy;
  x = spoints(i,2)+origx;
  % Calculate floors, ceils and rounds for the x and y.
  fy = floor(y); cy = ceil(y); ry = round(y);
  fx = floor(x); cx = ceil(x); rx = round(x);
  % Check if interpolation is needed.
  if (abs(x - rx) < 1e-6) && (abs(y - ry) < 1e-6)
    % Interpolation is not needed, use original datatypes
    N = d_image(ry:ry+dy,rx:rx+dx);
    D{i}   = N;
    sum_N  = sum_N + N;
    G1{i}  = abs(N - d_C);   
    G2{i}  = abs(N - thre_C);
    if i==1
        Tmax=N;
        Tmin=N;
    else
        Tmax=max(Tmax,N);
        Tmin=min(Tmin,N);
    end    
  else
    % Interpolation needed, use double type images 
    ty = y - fy;
    tx = x - fx;

    % Calculate the interpolation weights.
    w1 = (1 - tx) * (1 - ty);
    w2 =      tx  * (1 - ty);
    w3 = (1 - tx) *      ty ;
    w4 =      tx  *      ty ;
    % Compute interpolated pixel values
    N = w1*d_image(fy:fy+dy,fx:fx+dx) + w2*d_image(fy:fy+dy,cx:cx+dx) + ...
        w3*d_image(cy:cy+dy,fx:fx+dx) + w4*d_image(cy:cy+dy,cx:cx+dx); 
    D{i}   = N;
    sum_N  = sum_N + N;    
    G1{i}  = abs(N - d_C);  
    G2{i}  = abs(N - thre_C); 
    if i==1
        Tmax=N;
        Tmin=N;
    else
        Tmax=max(Tmax,N);
        Tmin=min(Tmin,N);
    end    
  end  
end
Miu=sum_N/P;
Tabs=abs(Tmax-Tmin);

for i=1:P
  v = 2^(i-1);
  G_D=(G2{i}./th_abs)>=(G1{i}./Tabs);
  g_diff=g_diff + v*G_D;
  VAR = VAR + (D{i}-Miu).^2;   
end

VAR = VAR/P;

VAR_compare{1}=VAR >=var_1 ;
VAR_compare{2}=VAR >=var_2 ;
VAR_compare{3}=VAR >=var_3 ;

for i=1:3
  v = 2^(i-1);
  VARC = VARC + v*VAR_compare{i};
end

%Apply mapping if it is defined
if isstruct(mapping)
    bins = mapping.num;
    sizarray = size(g_diff);
    g_diff = g_diff(:);
    g_diff = mapping.table(g_diff+1);
    g_diff = reshape(g_diff,sizarray);   

end


%% DIOM
C_result = d_C;%C_result��ӳ����������֮��Ĵ�С��ϵ�������ƣ�
% T = thre_C;
T = mean2(d_C);%���ĵ��ƽ���Ҷ�
l_idx = find(d_C >= T);%�ҳ�����ƽ���Ҷȵ�����λ������
ll_idx = find(d_C < T);%�ҳ�С��ƽ���Ҷȵ�����λ������
if (size(l_idx) >= size(ll_idx))%�������ƽ���Ҷȵ�����������С����С�ڵ�������С
    C_result(l_idx) = 1;%C_result�д���ƽ���Ҷȵ�ֵΪ1
    C_result(ll_idx) = 0;%C_result��С��ƽ���Ҷȵ�ֵΪ0
else
    C_result(l_idx) = 0;%C_result�д���ƽ���Ҷȵ�ֵΪ0
    C_result(ll_idx) = 1;%C_result��С��ƽ���Ҷȵ�ֵΪ1
end
LVT_C=C_result;
%% 
LVPjoint1=zeros(dy+1,dx+1);
% LVPjoint1=g_diff;
LVPjoint1=bins*VARC+g_diff;

if (strcmp(mode,'h') || strcmp(mode,'hist') || strcmp(mode,'nh'))
    LVPjoint1=hist(LVPjoint1(:),0:(8*bins-1));
else
    idx = find(LVT_C);
    LVPjoint_1 = LVPjoint1;
    LVPjoint_1(idx) = LVPjoint_1(idx)+8*bins;
    LVPjoint1=hist(LVPjoint_1(:),0:(2*8*bins-1));
end





